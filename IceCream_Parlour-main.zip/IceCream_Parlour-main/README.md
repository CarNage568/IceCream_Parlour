# IceCream_Parlour as a small project in c++ ;
Programmed an interactive interface of ice-cream parlor menu using C++  language. Added various modules for selling and generated bill with added taxes
